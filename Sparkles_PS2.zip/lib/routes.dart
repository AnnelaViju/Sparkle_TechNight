class MyRoutes {
  static String LoginRoute = "/login";
  static String ProfileRoute = "/profile";
}
