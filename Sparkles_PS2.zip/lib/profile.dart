import 'package:flutter/material.dart';

void main() => runApp(ProfileApp());

class ProfileApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BeHealthy',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ProfilePage(),
    );
  }
}

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  TextEditingController ageController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  TextEditingController heightController = TextEditingController();
  String fitnessLevel = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Profile'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "assets/heart.jpg",
              fit: BoxFit.cover,
            ),
            SizedBox(
              height: 20.0,
            ),
            TextField(
              controller: ageController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Age',
                hintText: 'Enter your age',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Weight (kg)',
                hintText: 'Enter your weight in kilograms',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Height (cm)',
                hintText: 'Enter your height in centimeters',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              child: Text('Calculate Fitness Level'),
              onPressed: () {
                setState(() {
                  int age = int.parse(ageController.text);
                  double weight = double.parse(weightController.text);
                  double height = double.parse(heightController.text);
                  double bmi = weight / ((height / 100) * (height / 100));
                  if (bmi < 18.5) {
                    fitnessLevel = 'Underweight';
                  } else if (bmi >= 18.5 && bmi < 25) {
                    fitnessLevel = 'Normal weight';
                  } else if (bmi >= 25 && bmi < 30) {
                    fitnessLevel = 'Overweight';
                  } else {
                    fitnessLevel = 'Obese';
                  }
                });
              },
            ),
            SizedBox(height: 16.0),
            Text(
              'Your fitness level is:',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              fitnessLevel,
              style: TextStyle(
                fontSize: 24.0,
                color: Colors.blue,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
