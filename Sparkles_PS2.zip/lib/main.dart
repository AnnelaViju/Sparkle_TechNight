import 'package:flutter/material.dart';
import 'login.dart';
import 'routes.dart';
import 'profile.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      themeMode: ThemeMode.light,

      theme: ThemeData(
        primarySwatch: Colors.pink,
        fontFamily: 'FontMain',
      ), // ThemeData

      darkTheme: ThemeData(
        brightness: Brightness.dark,
      ), // ThemeData

      initialRoute: "/",

      routes: {
        "/": (context) => LoginPage(),
        "/profile": (context) => ProfilePage(),
        MyRoutes.LoginRoute: (context) => LoginPage(),
        MyRoutes.ProfileRoute: (context) => ProfilePage()
      },
    ); // MaterialApp
  }
}
